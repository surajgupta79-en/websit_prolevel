import { MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export const ContactSection = () => {
  const address = "Azmi Nagar, Room No. 447 A, S. Road, Akashwani, Gate No. 7, Malvani, Malad (West), Mumbai - 95";
  const phones = [
    "7718069066", 
    "9869755810",
    "9819154820",
    "9930222870"
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-yellow-50 to-yellow-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 drop-shadow-lg">
            Contact <span className="text-yellow-600 drop-shadow-xl">Us</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto drop-shadow-md">
            Ready to start your project? Get in touch with Mumbai's most trusted transport service
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="animate-fade-in">
            <h3 className="text-3xl font-bold text-gray-900 mb-8 drop-shadow-lg">Get in Touch</h3>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4 p-6 bg-gradient-to-br from-white to-yellow-50 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-yellow-200" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 p-3 rounded-full shadow-lg">
                  <MapPin className="w-6 h-6 text-white drop-shadow-lg" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Our Location</h4>
                  <p className="text-gray-600 leading-relaxed">{address}</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-6 bg-gradient-to-br from-white to-yellow-50 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-yellow-200" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 p-3 rounded-full shadow-lg">
                  <Phone className="w-6 h-6 text-white drop-shadow-lg" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Phone Numbers</h4>
                  <div className="space-y-2">
                    {phones.map((phone, index) => (
                      <a 
                        key={index}
                        href={`tel:${phone}`}
                        className="block text-yellow-600 hover:text-yellow-700 font-semibold text-lg drop-shadow-md transition-colors"
                      >
                        +91 {phone}
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-6 bg-gradient-to-br from-white to-yellow-50 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-yellow-200" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 p-3 rounded-full shadow-lg">
                  <Clock className="w-6 h-6 text-white drop-shadow-lg" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Working Hours</h4>
                  <p className="text-gray-600">Monday - Sunday: 7:00 AM - 9:00 PM</p>
                  <p className="text-gray-600">Emergency Service: 24/7 Available</p>
                </div>
              </div>
            </div>

            {/* Action Buttons with 3D effect */}
            <div className="mt-8 space-y-4">
              <Button 
                size="lg"
                onClick={() => window.open(`tel:${phones[0]}`, '_self')}
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-bold text-lg py-4 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
                style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.4)' }}
              >
                <Phone className="w-5 h-5 mr-3" />
                Call Now: +91 {phones[0]}
              </Button>
              
              <Button 
                size="lg"
                variant="outline"
                onClick={() => window.open(`https://wa.me/91${phones[0]}`, '_blank')}
                className="w-full border-2 border-green-500 text-green-600 hover:bg-green-500 hover:text-white font-bold text-lg py-4 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
              >
                <MessageCircle className="w-5 h-5 mr-3" />
                WhatsApp Chat
              </Button>
            </div>
          </div>

          {/* Map with 3D effect */}
          <div className="animate-fade-in">
            <div className="bg-white rounded-xl shadow-2xl overflow-hidden h-full min-h-[500px] border-4 border-yellow-200" style={{ boxShadow: '0 20px 50px rgba(234, 179, 8, 0.3)' }}>
              <div className="p-6 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
                <h3 className="text-2xl font-bold mb-2 drop-shadow-lg">Find Us Here</h3>
                <p className="text-yellow-100 drop-shadow-md">Located in the heart of Malad West, Mumbai</p>
              </div>
              
              <div className="h-96">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15076.095394087467!2d72.8370!3d19.1759!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b6c67d4c3f7b%3A0x5c3b4e8b1c3e7f8a!2sMalvani%2C%20Malad%20West%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1635780000000!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Santosh Transport Location"
                ></iframe>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Contact Banner with 3D effect */}
        <div className="mt-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-xl p-8 text-center text-white animate-fade-in shadow-2xl border-4 border-yellow-300" style={{ boxShadow: '0 20px 50px rgba(234, 179, 8, 0.4)' }}>
          <h3 className="text-3xl font-bold mb-4 drop-shadow-xl">Need Immediate Service?</h3>
          <p className="text-xl mb-6 drop-shadow-lg">Our team is ready to help you with urgent transportation needs</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <span className="text-2xl font-bold drop-shadow-lg">📞 Emergency Hotline:</span>
            <Button 
              size="lg"
              onClick={() => window.open(`tel:${phones[0]}`, '_self')}
              className="bg-white text-yellow-600 hover:bg-yellow-50 font-bold text-xl px-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
            >
              +91 {phones[0]}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
