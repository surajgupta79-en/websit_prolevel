import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, Truck } from "lucide-react";

export const HeroSection = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-300 via-yellow-400 to-yellow-600 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-black bg-opacity-30">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-40"></div>
        {/* 3D Construction pattern overlay */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4xNSI+PHBhdGggZD0iTTM2IDM0di00aC0ydjRoLTR2Mmg0djRoMnYtNGg0di0yaC00em0wLTMwVjBoLTJ2NGgtNHYyaDR2NGgyVjZoNFY0aC00ek02IDM0di00SDR2NEgwdjJoNHY0aDJ2LTRoNHYtMkg2ek02IDRWMEG0djRIMHYyaDR2NGgyVjZoNFY0SDZ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30"></div>
      </div>
      
      {/* Animated 3D Construction Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-20 h-20 bg-yellow-200 opacity-30 rounded-lg shadow-xl transform rotate-45 animate-bounce" style={{ animationDelay: '0s', animationDuration: '3s', boxShadow: '10px 10px 30px rgba(234, 179, 8, 0.3)' }}></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-yellow-300 opacity-25 rounded-full shadow-2xl animate-bounce" style={{ animationDelay: '1s', animationDuration: '4s', boxShadow: '8px 8px 25px rgba(251, 191, 36, 0.4)' }}></div>
        <div className="absolute bottom-40 left-20 w-24 h-24 bg-yellow-100 opacity-20 rounded-xl shadow-xl transform -rotate-12 animate-bounce" style={{ animationDelay: '2s', animationDuration: '5s', boxShadow: '12px 12px 35px rgba(254, 240, 138, 0.3)' }}></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="animate-fade-in">
          {/* Om Sai Ram in Hindi with 3D effect */}
          <div className="mb-6 flex justify-center">
            <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full px-8 py-4 backdrop-blur-sm border-2 border-yellow-200 shadow-2xl transform hover:scale-105 transition-all duration-300" style={{ boxShadow: '0 15px 35px rgba(234, 179, 8, 0.4), inset 0 2px 10px rgba(255, 255, 255, 0.2)' }}>
              <span className="text-2xl md:text-3xl font-bold text-white tracking-wider drop-shadow-lg">ॐ साईं राम</span>
            </div>
          </div>
          
          <div className="mb-6 flex justify-center">
            <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full p-6 backdrop-blur-sm shadow-2xl transform hover:scale-110 transition-all duration-300" style={{ boxShadow: '0 20px 40px rgba(234, 179, 8, 0.5), inset 0 2px 15px rgba(255, 255, 255, 0.3)' }}>
              <Truck className="w-16 h-16 text-white animate-pulse drop-shadow-xl" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-4 leading-tight drop-shadow-2xl">
            <span className="block animate-[fade-in_1s_ease-out] bg-gradient-to-r from-white to-yellow-100 bg-clip-text text-transparent">Santosh</span>
            <span className="block text-yellow-200 animate-[fade-in_1s_ease-out_0.3s_both] drop-shadow-xl">Transport</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-2 font-semibold animate-[fade-in_1s_ease-out_0.6s_both] drop-shadow-lg">
            Specialist in Rabit Mitti Suppliers
          </p>
          <p className="text-lg md:text-xl mb-8 text-yellow-100 animate-[fade-in_1s_ease-out_0.9s_both] drop-shadow-lg">
            & JCB on Hire - Mumbai's Most Trusted Service
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-[fade-in_1s_ease-out_1.2s_both]">
            <Button 
              size="lg"
              onClick={() => window.open('tel:7718069066', '_self')}
              className="bg-gradient-to-r from-white to-yellow-50 text-yellow-700 hover:from-yellow-50 hover:to-white font-bold text-lg px-8 py-4 transition-all duration-300 hover:scale-105 shadow-2xl hover:shadow-3xl border-2 border-yellow-200"
              style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.4)' }}
            >
              <Phone className="w-5 h-5 mr-3" />
              Call Now: 77180 69066
            </Button>
            <Button 
              size="lg"
              onClick={() => window.open('https://wa.me/917718069066', '_blank')}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold text-lg px-8 py-4 transition-all duration-300 hover:scale-105 shadow-2xl hover:shadow-3xl border-2 border-green-400"
              style={{ boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.2)' }}
            >
              <MessageCircle className="w-5 h-5 mr-3" />
              WhatsApp Us
            </Button>
          </div>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 text-center animate-[fade-in_1s_ease-out_1.5s_both]">
            <div className="bg-gradient-to-br from-white/20 to-yellow-200/20 rounded-xl p-4 backdrop-blur-sm border border-yellow-300 hover:bg-white/30 transition-all duration-300 hover:scale-105 shadow-xl" style={{ boxShadow: '0 8px 25px rgba(234, 179, 8, 0.3)' }}>
              <h3 className="font-bold text-lg mb-2 drop-shadow-lg">Reliable Service</h3>
              <p className="text-sm drop-shadow-md">On-time delivery guaranteed</p>
            </div>
            <div className="bg-gradient-to-br from-white/20 to-yellow-200/20 rounded-xl p-4 backdrop-blur-sm border border-yellow-300 hover:bg-white/30 transition-all duration-300 hover:scale-105 shadow-xl" style={{ boxShadow: '0 8px 25px rgba(234, 179, 8, 0.3)' }}>
              <h3 className="font-bold text-lg mb-2 drop-shadow-lg">Expert Team</h3>
              <p className="text-sm drop-shadow-md">Experienced professionals</p>
            </div>
            <div className="bg-gradient-to-br from-white/20 to-yellow-200/20 rounded-xl p-4 backdrop-blur-sm border border-yellow-300 hover:bg-white/30 transition-all duration-300 hover:scale-105 shadow-xl" style={{ boxShadow: '0 8px 25px rgba(234, 179, 8, 0.3)' }}>
              <h3 className="font-bold text-lg mb-2 drop-shadow-lg">Mumbai Wide</h3>
              <p className="text-sm drop-shadow-md">Serving all Mumbai areas</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Enhanced 3D Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center bg-gradient-to-b from-yellow-200/30 to-white/20 backdrop-blur-sm shadow-xl" style={{ boxShadow: '0 5px 15px rgba(234, 179, 8, 0.4)' }}>
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse shadow-md"></div>
        </div>
      </div>
    </section>
  );
};
