
import { Truck, Settings, Package, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export const ServicesSection = () => {
  const services = [
    {
      icon: Package,
      title: "Rabit Mitti Supply",
      description: "High-quality construction sand delivered fresh to your site. Available in various quantities for projects of all sizes.",
      features: ["Premium quality sand", "Bulk orders available", "Fast delivery", "Competitive pricing"]
    },
    {
      icon: Settings,
      title: "JCB on Hire",
      description: "Well-maintained JCB machines with experienced operators for excavation, loading, and construction work.",
      features: ["Experienced operators", "Modern equipment", "Hourly/daily rates", "Emergency service"]
    },
    {
      icon: Truck,
      title: "Construction Material Delivery",
      description: "Comprehensive delivery service for all types of construction materials across Mumbai.",
      features: ["Door-to-door delivery", "Secure transportation", "Timely service", "Damage-free delivery"]
    },
    {
      icon: Phone,
      title: "Custom Transport Requests",
      description: "Specialized transportation solutions tailored to your specific construction and material needs.",
      features: ["Custom solutions", "Flexible scheduling", "Professional service", "Dedicated support"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-white to-yellow-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 drop-shadow-lg">
            Our <span className="text-yellow-600 drop-shadow-xl">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto drop-shadow-md">
            Comprehensive transportation and construction material solutions for Mumbai's building industry
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-8 shadow-2xl hover:shadow-3xl transition-all duration-300 hover:transform hover:scale-105 animate-fade-in border-2 border-yellow-200"
              style={{ animationDelay: `${index * 0.1}s`, boxShadow: '0 15px 40px rgba(234, 179, 8, 0.2)' }}
            >
              <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 w-16 h-16 rounded-full flex items-center justify-center mb-6 shadow-xl" style={{ boxShadow: '0 8px 25px rgba(234, 179, 8, 0.4)' }}>
                <service.icon className="w-8 h-8 text-white drop-shadow-lg" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4 drop-shadow-md">{service.title}</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
              
              <ul className="space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-gray-700">
                    <div className="w-3 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full mr-3 shadow-md"></div>
                    {feature}
                  </li>
                ))}
              </ul>
              
              <Button 
                variant="outline"
                onClick={() => window.open('tel:7718069066', '_self')}
                className="w-full border-2 border-yellow-500 text-yellow-700 hover:bg-gradient-to-r hover:from-yellow-500 hover:to-yellow-600 hover:text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Get Quote Now
              </Button>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 animate-fade-in">
          <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-white rounded-xl p-8 max-w-4xl mx-auto shadow-2xl border-4 border-yellow-300" style={{ boxShadow: '0 20px 50px rgba(234, 179, 8, 0.3)' }}>
            <h3 className="text-3xl font-bold mb-4 drop-shadow-lg">Ready to Get Started?</h3>
            <p className="text-xl mb-6 drop-shadow-md">
              Contact us today for competitive pricing and reliable service across Mumbai
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                onClick={() => window.open('tel:7718069066', '_self')}
                className="bg-white text-yellow-600 hover:bg-yellow-50 font-bold shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
              >
                <Phone className="w-5 h-5 mr-2" />
                Call: 77180 69066
              </Button>
              <Button 
                size="lg"
                variant="outline"
                onClick={() => window.open('https://wa.me/917718069066', '_blank')}
                className="border-2 border-white text-white hover:bg-white hover:text-yellow-600 font-bold shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
              >
                WhatsApp Quote
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
