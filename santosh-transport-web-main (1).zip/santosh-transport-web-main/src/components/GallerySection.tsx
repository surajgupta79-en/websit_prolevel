
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export const GallerySection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const images = [
    {
      url: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Heavy Construction Equipment",
      description: "Professional JCB excavators and heavy machinery for large construction projects"
    },
    {
      url: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Material Transportation",
      description: "Efficient transportation of construction materials and Rabit Mitti across Mumbai"
    },
    {
      url: "https://images.unsplash.com/photo-1469041797191-50ace28483c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Truck Fleet",
      description: "Reliable truck fleet for all your material delivery and transportation needs"
    },
    {
      url: "https://images.unsplash.com/photo-1449157291145-7efd050a4d0e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Construction Site Operations",
      description: "Professional construction site management and equipment rental services"
    },
    {
      url: "https://images.unsplash.com/photo-1487887235947-a955ef187fcc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Modern JCB Equipment",
      description: "Well-maintained JCB machines ready for excavation and construction work"
    },
    {
      url: "https://images.unsplash.com/photo-1527576539890-dfa815648363?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      title: "Infrastructure Development",
      description: "Supporting Mumbai's infrastructure development with quality equipment and materials"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <section id="gallery" className="py-20 bg-gradient-to-br from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-xl">
            Our <span className="text-yellow-400 drop-shadow-2xl">Gallery</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto drop-shadow-lg">
            See our equipment, delivery vehicles, and completed projects across Mumbai
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Main Carousel with 3D effect */}
          <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ boxShadow: '0 25px 60px rgba(234, 179, 8, 0.3)' }}>
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {images.map((image, index) => (
                <div key={index} className="w-full flex-shrink-0 relative">
                  <img 
                    src={image.url}
                    alt={image.title}
                    className="w-full h-96 md:h-[500px] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent">
                    <div className="absolute bottom-8 left-8 text-white">
                      <h3 className="text-2xl font-bold mb-2 drop-shadow-xl">{image.title}</h3>
                      <p className="text-gray-300 drop-shadow-lg">{image.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation Buttons with 3D effect */}
            <Button
              variant="outline"
              size="sm"
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-yellow-500/20 border-yellow-400 text-yellow-200 hover:bg-yellow-500 hover:text-black backdrop-blur-sm shadow-xl"
              onClick={prevSlide}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-yellow-500/20 border-yellow-400 text-yellow-200 hover:bg-yellow-500 hover:text-black backdrop-blur-sm shadow-xl"
              onClick={nextSlide}
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Dots Indicator with 3D effect */}
          <div className="flex justify-center mt-8 space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-300 shadow-lg ${
                  index === currentSlide 
                    ? 'bg-yellow-500 scale-125 shadow-yellow-500/50' 
                    : 'bg-gray-600 hover:bg-gray-500 hover:scale-110'
                }`}
                onClick={() => setCurrentSlide(index)}
                style={{ boxShadow: index === currentSlide ? '0 5px 15px rgba(234, 179, 8, 0.5)' : '0 2px 8px rgba(0, 0, 0, 0.3)' }}
              />
            ))}
          </div>
        </div>

        {/* Statistics with 3D effect */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 animate-fade-in">
          <div className="text-center p-6 bg-gradient-to-br from-yellow-500/10 to-yellow-600/20 rounded-xl border border-yellow-500/30 shadow-xl" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
            <div className="text-4xl font-bold text-yellow-400 mb-2 drop-shadow-xl">10+</div>
            <div className="text-gray-300 drop-shadow-lg">Years Experience</div>
          </div>
          <div className="text-center p-6 bg-gradient-to-br from-yellow-500/10 to-yellow-600/20 rounded-xl border border-yellow-500/30 shadow-xl" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
            <div className="text-4xl font-bold text-yellow-400 mb-2 drop-shadow-xl">500+</div>
            <div className="text-gray-300 drop-shadow-lg">Projects Completed</div>
          </div>
          <div className="text-center p-6 bg-gradient-to-br from-yellow-500/10 to-yellow-600/20 rounded-xl border border-yellow-500/30 shadow-xl" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
            <div className="text-4xl font-bold text-yellow-400 mb-2 drop-shadow-xl">50+</div>
            <div className="text-gray-300 drop-shadow-lg">JCB Fleet</div>
          </div>
          <div className="text-center p-6 bg-gradient-to-br from-yellow-500/10 to-yellow-600/20 rounded-xl border border-yellow-500/30 shadow-xl" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
            <div className="text-4xl font-bold text-yellow-400 mb-2 drop-shadow-xl">24/7</div>
            <div className="text-gray-300 drop-shadow-lg">Service Available</div>
          </div>
        </div>
      </div>
    </section>
  );
};
