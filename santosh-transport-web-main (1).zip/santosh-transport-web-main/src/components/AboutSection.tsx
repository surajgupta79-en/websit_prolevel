
import { Award, Clock, Shield, Users } from "lucide-react";

export const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-br from-yellow-50 to-yellow-100 relative overflow-hidden">
      {/* 3D Background construction pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNlYWIzMDgiIGZpbGwtb3BhY2l0eT0iMC4wOCI+PHBhdGggZD0iTTAgMGg0MHY0MEgwVjB6bTQwIDQwaDQwdjQwSDQwVjQwem0wLTQwaDJsLTIgMlYwem0wIDRsNC00aDJsLTYgNlY0em0wIDRsOC04aDJMNDAgMTBWOHptMCA0TDUyIDBoMkw0MCAxNHYtMnptMCA0TDU2IDBoMkw0MCAxOHYtMnptMCA0TDYwIDBoMkw0MCAyMnYtMnptMCA0TDY0IDBoMkw0MCAyNnYtMnptMCA0TDY4IDBoMkw0MCAzMHYtMnptMCA0TDcyIDBoMkw0MCAzNHYtMnptMCA0TDc2IDBoMkw0MCAzOHYtMnptMCA0TDgwIDB2Mkw0MiA0MGgtMnptNCAwTDgwIDR2Mkw0NiA0MGgtMnptNCAwTDgwIDh2Mkw1MCA0MGgtMnptNCAwbDI4LTI4djJMNTQgNDBoLTJ6bTQgMGwyNC0yNHYyTDU4IDQwaC0yem00IDBsMjAtMjB2Mkw2MiA0MGgtMnptNCAwbDE2LTE2djJMNjYgNDBoLTJ6bTQgMGwxMi0xMnYyTDcwIDQwaC0yem00IDBsOC04djJsLTYgNmgtMnptNCAwbDQtNHYyTDc4IDQwaC0yeiIvPjwvZz48L2c+PC9zdmc+')]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 drop-shadow-lg">
            About <span className="text-yellow-600 drop-shadow-xl">Santosh Transport</span>
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed drop-shadow-md">
            With over a decade of experience in Mumbai's transportation industry, Santosh Transport 
            has established itself as the premier provider of Rabit Mitti supply and JCB rental services.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <img 
              src="https://images.unsplash.com/photo-1487887235947-a955ef187fcc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
              alt="JCB excavator at construction site" 
              className="rounded-xl shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105 border-4 border-yellow-200"
              style={{ boxShadow: '0 20px 50px rgba(234, 179, 8, 0.3)' }}
            />
          </div>
          
          <div className="animate-fade-in">
            <h3 className="text-3xl font-bold text-gray-900 mb-6 drop-shadow-lg">
              Why Choose Us?
            </h3>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed drop-shadow-sm">
              We specialize in providing high-quality Rabit Mitti (construction sand) and reliable JCB 
              rental services across Mumbai. Our commitment to excellence and customer satisfaction 
              has made us the trusted choice for construction projects of all sizes.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-l-4 border-yellow-500" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <Award className="w-12 h-12 text-yellow-600 mx-auto mb-3 drop-shadow-lg" />
                <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Quality Assured</h4>
                <p className="text-sm text-gray-700">Premium grade materials</p>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-l-4 border-yellow-500" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <Clock className="w-12 h-12 text-yellow-600 mx-auto mb-3 drop-shadow-lg" />
                <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Fast Delivery</h4>
                <p className="text-sm text-gray-700">Same day service available</p>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-l-4 border-yellow-500" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <Shield className="w-12 h-12 text-yellow-600 mx-auto mb-3 drop-shadow-lg" />
                <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Trusted Partner</h4>
                <p className="text-sm text-gray-700">Reliable and professional</p>
              </div>
              
              <div className="text-center p-6 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-l-4 border-yellow-500" style={{ boxShadow: '0 10px 30px rgba(234, 179, 8, 0.2)' }}>
                <Users className="w-12 h-12 text-yellow-600 mx-auto mb-3 drop-shadow-lg" />
                <h4 className="font-bold text-gray-900 mb-2 drop-shadow-md">Expert Team</h4>
                <p className="text-sm text-gray-700">Experienced professionals</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
