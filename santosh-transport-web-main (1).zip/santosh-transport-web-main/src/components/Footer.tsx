
import { Heart } from "lucide-react";

export const Footer = () => {
  const phones = [
    "7718069066", 
    "9869755810",
    "9819154820",
    "9930222870"
  ];

  return (
    <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-12 relative overflow-hidden">
      {/* 3D Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-yellow-500/5"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Company Info with 3D effect */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 text-black font-bold text-xl px-3 py-2 rounded shadow-xl" style={{ boxShadow: '0 8px 25px rgba(234, 179, 8, 0.4)' }}>
                ST
              </div>
              <div>
                <h3 className="font-bold text-xl drop-shadow-lg">Santosh Transport</h3>
                <p className="text-gray-400 text-sm drop-shadow-md">Mumbai's Trusted Partner</p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed drop-shadow-md">
              Specialist in Rabit Mitti supply and JCB rental services across Mumbai. 
              Committed to quality, reliability, and customer satisfaction.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-4 text-yellow-400 drop-shadow-lg">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#hero" className="text-gray-300 hover:text-yellow-400 transition-colors drop-shadow-md hover:drop-shadow-lg">
                  Home
                </a>
              </li>
              <li>
                <a href="#about" className="text-gray-300 hover:text-yellow-400 transition-colors drop-shadow-md hover:drop-shadow-lg">
                  About Us
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-yellow-400 transition-colors drop-shadow-md hover:drop-shadow-lg">
                  Services
                </a>
              </li>
              <li>
                <a href="#gallery" className="text-gray-300 hover:text-yellow-400 transition-colors drop-shadow-md hover:drop-shadow-lg">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-yellow-400 transition-colors drop-shadow-md hover:drop-shadow-lg">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-lg mb-4 text-yellow-400 drop-shadow-lg">Contact Info</h4>
            <div className="space-y-3">
              <div>
                <span className="font-semibold text-yellow-300 drop-shadow-md">Phone Numbers:</span>
                <div className="mt-2 space-y-1">
                  {phones.map((phone, index) => (
                    <p key={index} className="text-gray-300 drop-shadow-md">
                      +91 {phone}
                    </p>
                  ))}
                </div>
              </div>
              <p className="text-gray-300 drop-shadow-md">
                <span className="font-semibold">Owner:</span> Maruti Dhotre
              </p>
              <p className="text-gray-300 text-sm leading-relaxed drop-shadow-md">
                Azmi Nagar, Room No. 447 A, S. Road, Akashwani, 
                Gate No. 7, Malvani, Malad (West), Mumbai - 95
              </p>
            </div>
          </div>
        </div>

        {/* Devotional Message with enhanced 3D effect */}
        <div className="border-t border-gray-800 pt-8 text-center">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black px-8 py-4 rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300" style={{ boxShadow: '0 15px 40px rgba(234, 179, 8, 0.5)' }}>
              <span className="text-2xl font-bold drop-shadow-lg">🚩 ॐ साईं राम 🚩</span>
            </div>
          </div>
          
          <div className="flex items-center justify-center space-x-3 mb-4">
            <span className="text-2xl animate-pulse drop-shadow-xl">🚩</span>
            <span className="text-xl font-bold text-yellow-400 drop-shadow-xl">जय श्री राम</span>
            <span className="text-2xl animate-pulse drop-shadow-xl">🚩</span>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-400 mb-4 md:mb-0 drop-shadow-md">
              © {new Date().getFullYear()} Santosh Transport. All rights reserved.
            </p>
            <p className="text-gray-400 flex items-center drop-shadow-md">
              Made with <Heart className="w-4 h-4 text-red-500 mx-1 animate-pulse drop-shadow-lg" /> for Mumbai's construction industry
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
